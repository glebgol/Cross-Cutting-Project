create function obj_description(oid) returns text
    stable
    strict
    parallel safe
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function obj_description(oid) is 'deprecated, use two-argument form instead';

alter function obj_description(oid) owner to postgres;

